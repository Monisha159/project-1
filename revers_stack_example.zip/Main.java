/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Scanner;
import java.util.Stack;

public class Main {
    public static boolean isInteger(String str) {
        if (str == null || str.isEmpty()) {
            return false;
        }
        int i = 0;
        if (str.charAt(0) == '-') {
            if (str.length() == 1) return false;
            i = 1;
        }
        for (; i < str.length(); i++) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    public static void main(String[] args) {
        Stack<Object> stack = new Stack<>();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of elements to push onto the stack: ");
        int n = scanner.nextInt();
        scanner.nextLine(); // consume leftover newline

        for (int i = 0; i < 10; i++) {
            System.out.print("Enter element #" + (i + 1) + ": ");
            String input = scanner.nextLine();

            if (isInteger(input)) {
                stack.push(Integer.parseInt(input));
            } else {
                stack.push(input);
            }
        }
        System.out.println("Original Stack: " + stack);

        Stack<Object> tempStack = new Stack<>();

        while (!stack.isEmpty()) {
            tempStack.push(stack.pop());
        }

        System.out.println("Reversed Stack: " + tempStack);
    }
}___aa 