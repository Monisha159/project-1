/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Collections;

public class Main {

    public static void useCase() {
        LinkedList<String> list = new LinkedList<>();

        list.add("A");
        list.add("B");
        list.add("C");

        list.add(1, "X"); 

        list.addFirst("Start");
        list.addLast("End"); 

        System.out.println("Element at index 2: " + list.get(2));  

        list.set(2, "Alpha"); 

        System.out.println("Contains 'B'? " + list.contains("B"));

        list.add("B"); 
        System.out.println("Index of B: " + list.indexOf("B"));   
        System.out.println("Last Index of B: " + list.lastIndexOf("B"));

        list.remove(1); 
        list.remove("End"); 

        list.removeFirst();
        list.removeLast();

        list.removeFirstOccurrence("B");

        list.push("Z"); 
        System.out.println("Popped: " + list.pop()); 


        LinkedList<String> extra = new LinkedList<>();
        extra.add("Y");
        extra.add("Z");
        list.addAll(extra);  
        
        
        LinkedList<String> clonedList = (LinkedList<String>) list.clone();
        System.out.println("Cloned List: " + clonedList);

        System.out.print("Descending Order: ");
        Iterator<String> desc = list.descendingIterator();
        while (desc.hasNext()) {
            System.out.print(desc.next() + " ");
        }
        System.out.println();

        list.clear();
        System.out.println("List after clear(): " + list);
    }

    public static void main(String[] args) {
        useCase();
    }
}
