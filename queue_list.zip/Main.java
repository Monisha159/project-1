/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

public class Main {

    static class MyQueue {
        ArrayList<Integer> list = new ArrayList<>();

        void enqueue(int data) {
            list.add(data);
        }

        int dequeue() {
            if (list.isEmpty()) {
                System.out.println("ArrayList Queue is Empty");
                return -1;
            }
            return list.remove(0);
        }

        int peek() {
            if (list.isEmpty()) {
                System.out.println("ArrayList Queue is Empty");
                return -1;
            }
            return list.get(0);
        }

        void display() {
            System.out.println("ArrayList Queue: " + list);
        }
    }

    public static void main(String[] args) {
        System.out.println("===== Queue using ArrayList =====");
        MyQueue q1 = new MyQueue();
        q1.enqueue(10);
        q1.enqueue(20);
        q1.enqueue(30);
        q1.display();
        System.out.println("Dequeue: " + q1.dequeue());
        q1.display();
        System.out.println("Peek: " + q1.peek());

        System.out.println("\n===== Queue using LinkedList =====");
        Queue<Integer> q2 = new LinkedList<>();
        q2.offer(100);
        q2.offer(200);
        q2.offer(300);
        System.out.println("LinkedList Queue: " + q2);
        System.out.println("Dequeue: " + q2.poll());
        System.out.println("Peek: " + q2.peek());
    }
}


