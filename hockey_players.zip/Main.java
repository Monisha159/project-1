import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter number of hockey players: ");
        int numberOfPlayers = scanner.nextInt();
        scanner.nextLine(); 
        
        String[] names = new String[numberOfPlayers];
        String[] positions = new String[numberOfPlayers];

        for (int i = 0; i < numberOfPlayers; i++) {
            System.out.println("Enter details for Player " + (i + 1));
            System.out.print("Name: ");
            names[i] = scanner.nextLine();

            System.out.print("Position (e.g., Forward, Defense, Goalie): ");
            positions[i] = scanner.nextLine();
        }
        System.out.println("\nHockey Players Info:");
        for (int i = 0; i < numberOfPlayers; i++) {
            System.out.println("Player " + (i + 1) + ": " + names[i] + " - " + positions[i]);
        }

        scanner.close();
    }
}
