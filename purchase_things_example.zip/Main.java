/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Stock> dresses = new ArrayList<>();

        System.out.print("Enter number of dresses: ");
        int numItems = scanner.nextInt();
        scanner.nextLine(); 
        for (int i = 0; i < numItems; i++) {
            System.out.print("Enter name of dress " + (i + 1) + ": ");
            String name = scanner.nextLine();

            System.out.print("Enter price of " + name + ": ");
            double price = scanner.nextDouble();
            scanner.nextLine();
e
            dresses.add(new Stock(name, price));
        }
        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine();
        Customer customer = new PremiumCustomer(customerName);

        Stock selectedStock = customer.charge(dresses);
        Purchase purchase = new Purchase(customer, selectedStock);
        purchase.summary();

        scanner.close();
    }
}

abstract class Customer {
    protected String name;
    protected UUID customerId;

    public Customer(String name) {
        this.name = name;
        this.customerId = UUID.randomUUID();
    }

    public abstract Stock charge(List<Stock> stocks);

    public String getName() {
        return name;
    }
}

class PremiumCustomer extends Customer {
    public PremiumCustomer(String name) {
        super(name);
    }

    public Stock charge(List<Stock> stocks) {
        Stock maxStock = Collections.max(stocks, Comparator.comparingDouble(Stock::getPrice));
        System.out.println(name + " is charged maximum price: $" + maxStock.getPrice() + " for " + maxStock.getName());
        return maxStock;
    }
}

class Stock {
    private String name;
    private double price;
    private UUID stockId;

    public Stock(String name, double price) {
        this.name = name;
        this.price = price;
        this.stockId = UUID.randomUUID();
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public UUID getStockId() {
        return stockId;
    }
}

class Purchase {
    private UUID purchaseId;
    private Customer customer;
    private Stock stock;

    public Purchase(Customer customer, Stock stock) {
        this.purchaseId = UUID.randomUUID();
        this.customer = customer;
        this.stock = stock;
    }

    public void summary() {
        System.out.println("Purchase ID: " + purchaseId +
                " , Customer: " + customer.getName() +
                " , Item: " + stock.getName() +
                " , Price: $" + stock.getPrice());
    }
}
