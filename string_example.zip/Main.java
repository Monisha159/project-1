/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.HashSet;
import java.util.Set;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Set<String> s = new HashSet<>();
        System.out.println("Set Elements: " + s);

        s.add("Geeks");
        s.add("For");
        s.add("Greeks");
        s.add("Example");
        s.add("Set");
        System.out.println(s);

        Set<String> a = new HashSet<>(Arrays.asList("monisha", "jeevana", "kaviya", "bhuvana"));
        Set<String> b = new HashSet<>(Arrays.asList("monisha", "jeevana", "subu", "sachu"));

        Set<String> u = new HashSet<>(a);
        u.addAll(b);
        System.out.println("Union of the two sets:");
        System.out.println(u);

        Set<String> i = new HashSet<>(a);
        i.retainAll(b);
        System.out.println("Intersection of the two sets:");
        System.out.println(i);
        Set<String> d = new HashSet<>(a);
        d.removeAll(b);
        System.out.println("Difference of two sets:");
        System.out.println(d);
        Set<String> t = new HashSet<>();
        t.add("B");
        t.add("B");
        t.add("C");
        t.add("A");
        System.out.println(t);

        Set<String> h = new HashSet<>();
        h.add("A");
        h.add("B");
        h.add("C");
        h.add("A");
        System.out.println("Set is " + h);

        String str = "D";
        System.out.println("Contains " + str + ": " + h.contains(str));

        Set<String> h2 = new HashSet<>();
        h2.add("A");
        h2.add("B");
        h2.add("C");
        h2.add("B");
        h2.add("D");
        h2.add("E");
        System.out.println("Initial HashSet: " + h2);

        h2.remove("B");
        System.out.println("After removing element B: " + h2);

        h2.add("A");
        h2.add("B");
        h2.add("C");
        h2.add("B");
        h2.add("E");
        for (String value : h2) {
            System.out.print(value + " , ");
        }
        System.out.println();
    }
}
