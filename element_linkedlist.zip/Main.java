/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;

public class Main {
    public static void main(String[] args) {
        LinkedList<String> ll = new LinkedList<>();
        
        ll.add("karthi");
        ll.add("raj");
        ll.add(1, "ravi");
        System.out.println(ll);
        
        ll.set(1, "ajay");
        
        System.out.println("Initial LinkedList: " + ll);
        
        ll.remove(1);
        
        System.out.println("Updated LinkedList: " + ll);
        
        ll.remove(1);
        System.out.println("After the Index Removal: " + ll);
        
        ll.remove("karthi");  
        System.out.println("After the Object Removal: " + ll);
        
        System.out.println("\nUsing for loop:");
        for (int i = 0; i < ll.size(); i++) {
            System.out.print(ll.get(i) + " ");
        }
        System.out.println();
        
        System.out.println("\nUsing for-each loop:");
        for (String str : ll) {
            System.out.print(str + " ");
        }
        System.out.println();
        
        LinkedList<Integer> list = new LinkedList<>();
        list.add(123);
        list.add(12);
        list.add(11);
        list.add(1134);
        System.out.println("LinkedList: " + list);
        
        Object[] a = list.toArray();
        System.out.println("After converting LinkedList to Array:");
        for (Object element : a){
            System.out.print(element + " ");
        }
        System.out.println();

        System.out.println("The first element is removed: " + list.removeFirst());  
        System.out.println("LinkedList after removing first element: " + list);   
        System.out.println("The last element is removed: " + list.removeLast());   
        System.out.println("LinkedList after removing last element: " + list);   

        System.out.println("Final LinkedList: " + list);

        LinkedList<Integer> linkedList = new LinkedList<>(); 

        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);

        linkedList.addFirst(0);  
        linkedList.addLast(4);

        System.out.println("Elements in linkedList:");
        for(int i : linkedList) {
            System.out.println(i);
        }
    }
}
