/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.LinkedList;
import java.util.Queue;

class CustomerServiceQueue {
    private Queue<String> queue;

    public CustomerServiceQueue() {
        queue = new LinkedList<>();
    }

    public void addCustomer(String customerName) {
        System.out.println("Adding customer: " + customerName);
        queue.add(customerName);
    }

    public void serveCustomers() {
        System.out.println("\n--- Serving Customers ---");

        while (!queue.isEmpty()) {
            if (queue.size() < 5) {
                System.out.println("Busy hour: More than 2 customers waiting.");
            }

            String customer = queue.poll();
            System.out.println("Serving: " + customer);
        }

        if (queue.isEmpty()) {
            System.out.println("All customers have been served.");
        }
    }
}

public class Main {
    public static void main(String[] args) {
        CustomerServiceQueue serviceQueue = new CustomerServiceQueue();

        serviceQueue.addCustomer("monisha");
        serviceQueue.addCustomer("kaviya");
        serviceQueue.addCustomer("bhuvana");
        serviceQueue.addCustomer("raja");

        serviceQueue.serveCustomers();
    }
}


