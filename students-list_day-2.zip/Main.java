/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
import java.util.Scanner;

class Student {  
    String name;
    int marks;
    String grade;

    Student(String name, int marks) {
        this.name = name;
        this.marks = marks;
        this.grade = calculateGrade(marks);
    }

    
    private String calculateGrade(int marks) {
        if (marks >= 90) {
            return "A+";
        } else if (marks >= 80) {
            return "A";
        } else if (marks >= 70) {
            return "B";
        } else if (marks >= 60) {
            return "C";
        } else if (marks >= 50) {
            return "D";
        } else {
            return "Fail";
        }
    }

    void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
        System.out.println("Grade: " + grade);
       
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> students = new ArrayList<>();

        
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter name of Student " + (i + 1) + ": ");
            String name = scanner.next();

            System.out.print("Enter marks of " + name + " (out of 100): ");
            int marks = scanner.nextInt();

           
            students.add(new Student(name, marks));
            System.out.println();
        }

      
        System.out.println("=== Student Mark List ===");
        for (Student student : students) {
            student.displayInfo();
        }

        scanner.close();
    }
}