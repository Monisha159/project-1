/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.PriorityQueue;
import java.util.Deque;
import java.util.ArrayDeque;

public class Main {
    public static void main(String[] args) {
        System.out.println("\n2. Circular Queue (Manual Implementation):");

        int size = 5;
        String[] circularQueue = new String[size];
        int front = -1, rear = -1;

        for (int i = 0; i < 3; i++) {
            if ((rear + 1) % size == front) {
                System.out.println("Queue is Full");
            } else {
                rear = (rear + 1) % size;
                circularQueue[rear] = "Item" + (i + 1);
                if (front == -1) front = 0;
            }
        }

        if (front == -1) {
            System.out.println("Queue is Empty");
        } else {
            int i = front;
            System.out.println("Circular Queue:");
            while (i != rear) {
                System.out.print(circularQueue[i] + ", ");
                i = (i + 1) % size;
            }
            System.out.println(circularQueue[i]);
        }

        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        priorityQueue.offer(30);
        priorityQueue.offer(10);
        priorityQueue.offer(20);

        System.out.println("\n3. Priority Queue: " + priorityQueue);
        System.out.println("Polled: " + priorityQueue.poll());

        Deque<String> deque = new ArrayDeque<>();
        deque.addFirst("Front");
        deque.addLast("Rear");

        System.out.println("\n4. Deque: " + deque);
        System.out.println("Removed Front: " + deque.removeFirst());
        System.out.println("Removed Rear: " + deque.removeLast());
    }
}
