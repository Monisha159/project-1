/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main {
    public static void main(String[] args) {
        Student[] arr = new Student[5];
        
        arr[0] = new Student(1, "monisha");
        arr[1] = new Student(2, "jeevena");
        arr[2] = new Student(3, "kaviya");
        arr[3] = new Student(4, "jithu");
        arr[4] = new Student(5, "reshu");
        
        for (int i = 0; i < arr.length; i++) {
            System.out.println("Element at " + i + ": " + arr[i].roll_no + " " + arr[i].name);
        }
    }
}

class Student {
    int roll_no;
    String name;

    Student(int roll_no, String name) {
        this.roll_no = roll_no;
        this.name = name;
    }
}
