/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.Stack;

public class Main {

    static void stack_push(Stack<Integer> stack) {
        System.out.print("Push Operation: ");
        for (int i = 0; i < 5; i++) {
            stack.push(i);
            System.out.print(i + " ");
        }
        System.out.println();
    }

    static void stack_pop(Stack<Integer> stack) {
        System.out.print("Pop Operation: ");
        for (int i = 0; i < 5; i++) {
            Integer popped = stack.pop();
            System.out.print(popped + " ");
        }
        System.out.println();
    }
    static void stack_peek(Stack<Integer> stack) {
        Integer top = stack.peek();
        System.out.println("Peek Operation: Top element is " + top);
    }

    static void stack_search(Stack<Integer> stack, int element) {
        int pos = stack.search(element);
        if (pos == -1)
            System.out.println("Element " + element + " not found in the stack");
        else
            System.out.println("Element " + element + " found at position: " + pos);
    }

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        stack_push(stack);
        stack_peek(stack);
        stack_search(stack, 2);
        stack_search(stack, 6);
        stack_pop(stack);
    }
}
