/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        LinkedList<String> list1 = new LinkedList<String>();

        list1.add("One");
        list1.add("Two");
        list1.add("Three");
        list1.add("Four");
        list1.add("Five");
        System.out.println(list1);

        LinkedList<String> list2 = new LinkedList<String>();

        list2.add("A");
        list2.add("B");
        list2.addLast("C");
        list2.addFirst("D");
        list2.add(2, "E");

        System.out.println(list2);

        list2.remove("B");
        list2.remove(3);
        list2.removeFirst();
        list2.removeLast();

        System.out.println(list2);
    }
}
