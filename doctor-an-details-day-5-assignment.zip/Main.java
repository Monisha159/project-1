import java.util.*;
class Doctor {
    int id;
    String name;
    Doctor(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
class Patient {
    int id;
    String name;

    Patient(int id, String name) {
        this.id = id;
        this.name = name;
    }
}
class Appointment {
    Doctor doctor;
    Patient patient;
    String time;
    Appointment(Doctor doctor, Patient patient, String time) {
        this.doctor = doctor;
        this.patient = patient;
        this.time = time;
    }
    void display() {
        System.out.println("Appointment: Doctor " + doctor.name +" with Patient " + patient.name + " at " + time);
    }
}
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue<Appointment> appointmentQueue = new LinkedList<>();
        Stack<Doctor> doctorStack = new Stack<>();
        HashMap<Integer, String> doctorMap = new HashMap<>();
        HashMap<Integer, String> patientMap = new HashMap<>();
        System.out.print("Enter number of doctors: ");++
        int docCount = scanner.nextInt();
        scanner.nextLine(); 
        for (int i = 0; i < docCount; i++) {
            System.out.print("Enter doctor ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter doctor name: ");
            String name = scanner.nextLine();

            doctorStack.push(new Doctor(id, name));
            doctorMap.put(id, name);
        }
        System.out.print("Enter number of patients: ");
        int patCount = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 0; i < patCount; i++) {
            System.out.print("Enter patient ID: ");
            int id = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Enter patient name: ");
            String name = scanner.nextLine();
            patientMap.put(id, name);
        }
        System.out.println("\nAssigning Appointments:");
        while (!doctorStack.isEmpty()) {
            Doctor doctor = doctorStack.pop();
            System.out.print("Enter patient ID for Doctor " + doctor.name + ": ");
            int patId = scanner.nextInt();
            scanner.nextLine(); 
            if (patientMap.containsKey(patId)) {
                System.out.print("Enter appointment time (e.g., 10:30 AM): ");
                String time = scanner.nextLine();
                Patient patient = new Patient(patId, patientMap.get(patId));
                Appointment appointment = new Appointment(doctor, patient, time);
                appointmentQueue.add(appointment);
            } else {
                System.out.println("Invalid Patient ID.");
            }
        }
        System.out.println("\n--- Appointments Scheduled ---");
        while (!appointmentQueue.isEmpty()) {
            Appointment a = appointmentQueue.poll();
            a.display();
        }
        System.out.println("\n--- Doctor List ---");
        for (Map.Entry<Integer, String> entry : doctorMap.entrySet()) {
            System.out.println("Doctor ID: " + entry.getKey() + ", Name: " + entry.getValue());
        }
        scanner.close();
    }
}
