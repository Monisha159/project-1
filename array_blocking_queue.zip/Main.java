/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.concurrent.ArrayBlockingQueue;

public class Main {
    
    public static void main(String[] args) {
        ArrayBlockingQueue<String> queue = new ArrayBlockingQueue<>(5);
        try {
            queue.put("Item1");
            queue.put("Item2");
            queue.put("Item3");
            queue.put("Item4");
            queue.put("Item5");

            System.out.println("Queue after insertion: " + queue);

            System.out.println("Polled: " + queue.take());
            System.out.println("Polled: " + queue.take());

            System.out.println("Queue after polling 2 items: " + queue);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
